
export interface Department{
    id:number;
    name:String;
}