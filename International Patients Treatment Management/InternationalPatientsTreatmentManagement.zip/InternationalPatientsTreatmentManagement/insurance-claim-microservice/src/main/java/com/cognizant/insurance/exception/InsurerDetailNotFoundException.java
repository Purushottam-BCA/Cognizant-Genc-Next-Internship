package com.cognizant.insurance.exception;


public class InsurerDetailNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsurerDetailNotFoundException(String message) {
		super(message);
	}

	public InsurerDetailNotFoundException() {
		
	}

	
	
}
