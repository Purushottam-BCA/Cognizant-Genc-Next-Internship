package com.cognizant.model;


public class UserDetail {
	
	@SuppressWarnings("unused")
	private String name;
}
